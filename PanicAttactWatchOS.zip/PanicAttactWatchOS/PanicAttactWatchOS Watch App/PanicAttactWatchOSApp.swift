//
//  PanicAttactWatchOSApp.swift
//  PanicAttactWatchOS Watch App
//
//  Created by Pieter Yoshua Natanael on 20/09/23.
//

import SwiftUI

@main
struct PanicAttactWatchOS_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
